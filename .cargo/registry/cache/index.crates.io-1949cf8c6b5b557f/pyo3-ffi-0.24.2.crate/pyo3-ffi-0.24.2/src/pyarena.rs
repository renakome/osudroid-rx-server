opaque_struct!(PyArena);
